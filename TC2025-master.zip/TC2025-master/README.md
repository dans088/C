# TC2025
Advanced Programming @ Tec de Monterrey

Examples of programs shown in class
